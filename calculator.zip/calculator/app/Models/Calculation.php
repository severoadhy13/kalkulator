<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

// Menghubungkan model ke tabel database yang busa diisi
class Calculation extends Model
{
    protected $fillable = ['expression', 'result'];
}
