<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Calculation;

class CalculatorController extends Controller
{
    // Menampilkan jawaban terakhir pada kolom input dan menampilkan riwayat perhitungan
    public function index()
    {
        $previousResult = Calculation::latest()->value('result');
        $calculations = Calculation::latest()->paginate(10);

        return view('calculator.index', compact('previousResult', 'calculations'));
    }

    // Fungsi perhitungan kalkulator
    public function calculate(Request $request)
    {
        $expression = $request->input('expression');
        $result = eval('return '.$expression.';');

        Calculation::create([
            'expression' => $expression,
            'result' => $result,
        ]);

        return redirect('/')->with('success', 'Calculation saved successfully.');
    }
}
