<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\CalculatorController;

//Mengambil inputan
Route::get('/', [CalculatorController::class, 'index']);

//Untuk menghitung dan mengirim data dari fungsi yang dijalankan
Route::post('/calculate', [CalculatorController::class, 'calculate']);
