<!-- Merapikan tampilan -->

<!DOCTYPE html>
<html>
<head>
    <title>Calculator</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 8px;
            border-bottom: 1px solid #ddd;
        }
    </style>
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>
</body>
</html>
<?php /**PATH E:\Tugas UNS\calculator\resources\views/layout/app.blade.php ENDPATH**/ ?>