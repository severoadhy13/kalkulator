<!-- resources/views/calculator/index.blade.php -->



<?php $__env->startSection('content'); ?>    
    <!-- Menampilkan box input dan submit  -->
    <div>
        <h1>Kalkulator</h1>
        <form method="POST" action="/calculate">
            <?php echo csrf_field(); ?>
            <input type="text" name="expression" placeholder="Enter an expression" value="<?php echo e($previousResult); ?>" required>
            <button type="submit">Calculate</button>
        </form>
    </div>

    <!-- Menampilkan riwayat perhitungan -->
    <div>
        <h3>Riwayat Perhitungan</h3>
        <table>
            <thead>
                <tr>
                    <th>Input</th>
                    <th>Hasil</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $calculations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $calculation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($calculation->expression); ?></td>
                        <td><?php echo e($calculation->result); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Tugas UNS\calculator\resources\views/calculator/index.blade.php ENDPATH**/ ?>