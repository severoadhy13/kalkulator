<!-- resources/views/calculator/index.blade.php -->

@extends('layout.app')

@section('content')    
    <!-- Menampilkan box input dan submit  -->
    <div>
        <h1>Kalkulator</h1>
        <form method="POST" action="/calculate">
            @csrf
            <input type="text" name="expression" placeholder="Enter an expression" value="{{ $previousResult }}" required>
            <button type="submit">Calculate</button>
        </form>
    </div>

    <!-- Menampilkan riwayat perhitungan -->
    <div>
        <h3>Riwayat Perhitungan</h3>
        <table>
            <thead>
                <tr>
                    <th>Input</th>
                    <th>Hasil</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($calculations as $calculation)
                    <tr>
                        <td>{{ $calculation->expression }}</td>
                        <td>{{ $calculation->result }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
