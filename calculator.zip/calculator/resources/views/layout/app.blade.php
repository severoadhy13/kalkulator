<!-- Merapikan tampilan -->

<!DOCTYPE html>
<html>
<head>
    <title>Calculator</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 8px;
            border-bottom: 1px solid #ddd;
        }
    </style>
</head>
<body>
    @yield('content')
</body>
</html>
